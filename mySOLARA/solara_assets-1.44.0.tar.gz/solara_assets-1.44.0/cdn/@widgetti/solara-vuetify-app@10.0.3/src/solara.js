export { RenderMimeRegistry, WidgetManager, connectKernel, extendedRendererFactories, KatexTypesetter, renderKatex, shutdownKernel } from '@widgetti/solara-widget-manager';
