# 01 - 基本

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example01Basic.vue)

<ClientOnly>
<Example01Basic></Example01Basic>
</ClientOnly>

