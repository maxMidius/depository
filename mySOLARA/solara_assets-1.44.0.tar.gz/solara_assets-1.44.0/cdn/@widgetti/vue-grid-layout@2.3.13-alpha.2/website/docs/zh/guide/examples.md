# 例子

## 基本

<Grid01Basic></Grid01Basic>

## 事件

<Grid02Events></Grid02Events>

## 多个网格

<Grid03MultipleGrids></Grid03MultipleGrids>

## 拖动允许/忽略元素

忽略对某些元素的拖动，而对其他元素允许。

单击并拖动每个栅格角上的点以重新定位

<Grid04AllowIgnore></Grid04AllowIgnore>
