# 04 - Drag allow/ignore elements 

Ignore drag on certain elements and allow on others.

Click and drag the dots on the corner of each item to reposition

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example04AllowIgnore.vue)

<ClientOnly>
<Example04AllowIgnore></Example04AllowIgnore>
</ClientOnly>

