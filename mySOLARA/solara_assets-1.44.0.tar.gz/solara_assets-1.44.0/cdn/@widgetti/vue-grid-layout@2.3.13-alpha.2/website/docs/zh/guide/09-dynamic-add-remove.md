# 09 - 动态添加/删除

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example09DynamicAddRemove.vue)

<ClientOnly>
<!--iframe style="border:0;width: 100%;height:800px;" src="../examples/09-dynamic-add-remove.html">
</iframe-->
<Example09DynamicAddRemove></Example09DynamicAddRemove>
</ClientOnly>
