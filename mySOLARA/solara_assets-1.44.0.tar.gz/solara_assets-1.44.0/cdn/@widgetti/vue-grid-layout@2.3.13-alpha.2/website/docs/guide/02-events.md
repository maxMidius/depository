# 02 - Move and resize events 

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example02Events.vue)

<ClientOnly>
<Example02Events></Example02Events>
</ClientOnly>
