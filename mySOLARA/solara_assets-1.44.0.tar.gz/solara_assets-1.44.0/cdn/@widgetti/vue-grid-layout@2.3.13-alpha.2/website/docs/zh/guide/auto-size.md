# 自动调整栅格元素

待办： https://github.com/jbaysolutions/vue-grid-layout/issues/351
