# Auto Sizing Grid Items

TODO: https://github.com/jbaysolutions/vue-grid-layout/issues/351
