# 08 - Responsive with predefined layouts 

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example08ResponsivePredefinedLayouts.vue)

<ClientOnly>
<Example08ResponsivePredefinedLayouts></Example08ResponsivePredefinedLayouts>
</ClientOnly>
