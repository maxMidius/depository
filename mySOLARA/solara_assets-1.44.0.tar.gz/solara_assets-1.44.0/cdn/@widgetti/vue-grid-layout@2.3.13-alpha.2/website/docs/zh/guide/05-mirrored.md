# 05 - 镜像反转栅格布局

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example05Mirrored.vue)

<ClientOnly>
<Example05Mirrored></Example05Mirrored>
</ClientOnly>

