# 06 - 响应式

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example06Responsive.vue)

<ClientOnly>
<!--iframe style="border:0;width: 100%;height:3000px;" src="../examples/06-responsive.html"></iframe-->
<Example06Responsive></Example06Responsive>
</ClientOnly>

