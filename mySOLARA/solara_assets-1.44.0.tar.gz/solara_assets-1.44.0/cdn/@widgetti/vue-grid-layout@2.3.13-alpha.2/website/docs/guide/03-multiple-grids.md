# 03 - Multiple grids 

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example03MultipleGrids.vue)

<ClientOnly>
<Example03MultipleGrids></Example03MultipleGrids>
</ClientOnly>

