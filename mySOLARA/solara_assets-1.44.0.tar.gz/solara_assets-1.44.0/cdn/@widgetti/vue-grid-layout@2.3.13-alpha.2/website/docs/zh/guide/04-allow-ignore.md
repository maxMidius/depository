# 04 - 拖动允许/忽略元素

忽略对某些元素的拖动而对其他元素的允许。

单击并拖动每个项目角上的点以重新定位

[查看资料](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example04AllowIgnore.vue)

<ClientOnly>
<Example04AllowIgnore></Example04AllowIgnore>
</ClientOnly>

