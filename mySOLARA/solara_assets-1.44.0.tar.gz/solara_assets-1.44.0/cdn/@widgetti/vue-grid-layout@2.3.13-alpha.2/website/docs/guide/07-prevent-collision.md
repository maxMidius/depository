# 07 - Prevent Collision 

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example07PreventCollision.vue)

<ClientOnly>
<!--iframe style="border:0;width: 100%;height:1000px;" src="../examples/07-prevent-collision.html"></iframe-->
<Example07PreventCollision></Example07PreventCollision>
</ClientOnly>
