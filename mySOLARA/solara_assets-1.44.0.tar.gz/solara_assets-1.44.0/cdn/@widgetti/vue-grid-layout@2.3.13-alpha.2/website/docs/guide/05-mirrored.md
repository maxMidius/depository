# 05 - Mirrored grid layout 

[View source](https://github.com/jbaysolutions/vue-grid-layout/blob/master/website/docs/.vuepress/components/Example05Mirrored.vue)

<ClientOnly>
<Example05Mirrored></Example05Mirrored>
</ClientOnly>

